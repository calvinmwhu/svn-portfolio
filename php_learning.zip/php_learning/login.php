<?php
/**
 * Created by PhpStorm.
 * User: calvinmwhu
 * Date: 4/5/15
 * Time: 7:21 PM
 */


$hn = 'localhost'; $db = 'test2'; $un = 'newuser';
$pw = 'newuser';

?>