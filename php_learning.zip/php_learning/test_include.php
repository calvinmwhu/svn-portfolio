<?php
/**
 * Created by PhpStorm.
 * User: calvinmwhu
 * Date: 3/28/15
 * Time: 12:23 PM
 */

$color = '32red';
$test = 'new';