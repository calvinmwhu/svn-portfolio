<?php
$xmlDoc = new DOMDocument();
$xmlDoc->load("svn_list.xml");

//$x = $xmlDoc->
//echo $xmlDoc->saveXML();

?>